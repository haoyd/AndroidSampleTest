package com.sample.speechvoice;

import android.app.Application;

import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechUtility;

/**
 * Created by haoyundong on 2017/4/17.
 */

public class MyApplication extends Application {

    public static final String VOICE_APP_ID = "58f470cb";

    @Override
    public void onCreate() {
        super.onCreate();
        initVoice();
    }

    private void initVoice() {
        SpeechUtility.createUtility(this, SpeechConstant.APPID + "=" + VOICE_APP_ID);
    }
}
